const url = 'https://restcountries.eu/rest/v2/all';

// Enter your code here
