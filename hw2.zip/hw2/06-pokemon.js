const url = 'https://pokeapi.co/api/v2/pokemon/';

// Enter your code here
